
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Search as SearchIcon, MapPin, Phone, Clock, Star, ChevronDown, ChevronUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';

// Updated dummy data for pharmacies in Guntur with proper local addresses
const dummyPharmacies = [
  {
    id: 'p1',
    name: 'Krishna Medical Store',
    address: 'Arundelpet, Guntur, Andhra Pradesh 522002',
    phone: '(0863) 223-4567',
    hours: '8:00 AM - 9:00 PM',
    rating: 4.7,
    distance: 0.8,
    isOpen: true,
    image: 'https://images.unsplash.com/photo-1586015555751-63c29b4bd310?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    medicineCount: 128,
    latitude: 16.3067,
    longitude: 80.4365
  },
  {
    id: 'p2',
    name: 'Guntur Central Pharmacy',
    address: 'Lakshmipuram, Guntur, Andhra Pradesh 522007',
    phone: '(0863) 987-6543',
    hours: '9:00 AM - 7:00 PM',
    rating: 4.3,
    distance: 1.2,
    isOpen: true,
    image: 'https://images.unsplash.com/photo-1576602976047-174e57a47881?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    medicineCount: 95,
    latitude: 16.3057,
    longitude: 80.4477
  },
  {
    id: 'p3',
    name: 'Lalitha Pharmacy',
    address: 'Brodipet, Guntur, Andhra Pradesh 522002',
    phone: '(0863) 456-7890',
    hours: '8:30 AM - 8:00 PM',
    rating: 4.5,
    distance: 2.5,
    isOpen: false,
    image: 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    medicineCount: 142,
    latitude: 16.3106,
    longitude: 80.4490
  },
  {
    id: 'p4',
    name: 'Apollo Pharmacy',
    address: 'Gujjanagundla, Guntur, Andhra Pradesh 522006',
    phone: '(0863) 234-5678',
    hours: '24 Hours',
    rating: 4.8,
    distance: 3.1,
    isOpen: true,
    image: 'https://images.unsplash.com/photo-1583339793403-3d5c6c97c90e?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    medicineCount: 187,
    latitude: 16.2936,
    longitude: 80.4365
  },
  {
    id: 'p5',
    name: 'MedPlus Pharmacy',
    address: 'Chandramouli Nagar, Guntur, Andhra Pradesh 522007',
    phone: '(0863) 876-5432',
    hours: '9:00 AM - 10:00 PM',
    rating: 4.2,
    distance: 4.7,
    isOpen: true,
    image: 'https://images.unsplash.com/photo-1631549916768-4119b4123a21?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    medicineCount: 76,
    latitude: 16.3122,
    longitude: 80.4536
  },
  {
    id: 'p6',
    name: 'Wellness Pharmacy',
    address: 'Amaravathi Road, Guntur, Andhra Pradesh 522020',
    phone: '(0863) 345-6789',
    hours: '8:00 AM - 7:00 PM',
    rating: 4.6,
    distance: 5.3,
    isOpen: false,
    image: 'https://images.unsplash.com/photo-1578683010236-d716f9a3f461?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    medicineCount: 112,
    latitude: 16.3215,
    longitude: 80.4298
  }
];

const Pharmacies = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [pharmacies, setPharmacies] = useState<typeof dummyPharmacies>([]);
  const [filteredPharmacies, setFilteredPharmacies] = useState<typeof dummyPharmacies>([]);
  const [selectedPharmacy, setSelectedPharmacy] = useState<string | null>(null);
  const [sortOption, setSortOption] = useState('distance');

  useEffect(() => {
    const fetchPharmacies = async () => {
      await new Promise(resolve => setTimeout(resolve, 1000));
      setPharmacies(dummyPharmacies);
      setFilteredPharmacies(dummyPharmacies);
      setIsLoading(false);
    };

    fetchPharmacies();

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          console.log('User location acquired:', position.coords.latitude, position.coords.longitude);
        },
        (error) => {
          console.log('Geolocation error:', error);
        }
      );
    }
  }, []);

  useEffect(() => {
    if (!pharmacies.length) return;

    let results = [...pharmacies];
    
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      results = results.filter(pharmacy => 
        pharmacy.name.toLowerCase().includes(term) || 
        pharmacy.address.toLowerCase().includes(term)
      );
    }
    
    switch (sortOption) {
      case 'distance':
        results.sort((a, b) => a.distance - b.distance);
        break;
      case 'rating':
        results.sort((a, b) => b.rating - a.rating);
        break;
      case 'name':
        results.sort((a, b) => a.name.localeCompare(b.name));
        break;
      default:
        results.sort((a, b) => a.distance - b.distance);
    }
    
    setFilteredPharmacies(results);
  }, [searchTerm, pharmacies, sortOption]);

  const togglePharmacyDetails = (pharmacyId: string) => {
    if (selectedPharmacy === pharmacyId) {
      setSelectedPharmacy(null);
    } else {
      setSelectedPharmacy(pharmacyId);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Nearby Pharmacies</h1>
      
      <div className="flex flex-col md:flex-row items-start md:items-center mb-6">
        <div className="relative flex-grow mb-4 md:mb-0">
          <Input
            type="text"
            placeholder="Search pharmacies by name or address..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 pr-4 py-2 rounded-md border border-gray-300 w-full"
          />
          <SearchIcon className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
        </div>
        
        <div className="flex md:ml-4 space-x-2">
          <Button
            variant={sortOption === 'distance' ? 'default' : 'outline'}
            size="sm"
            className={sortOption === 'distance' ? 'bg-medibleu-500 hover:bg-medibleu-600' : 'border-gray-300'}
            onClick={() => setSortOption('distance')}
          >
            Nearest
          </Button>
          <Button
            variant={sortOption === 'rating' ? 'default' : 'outline'}
            size="sm"
            className={sortOption === 'rating' ? 'bg-medibleu-500 hover:bg-medibleu-600' : 'border-gray-300'}
            onClick={() => setSortOption('rating')}
          >
            Highest Rated
          </Button>
          <Button
            variant={sortOption === 'name' ? 'default' : 'outline'}
            size="sm"
            className={sortOption === 'name' ? 'bg-medibleu-500 hover:bg-medibleu-600' : 'border-gray-300'}
            onClick={() => setSortOption('name')}
          >
            Alphabetical
          </Button>
        </div>
      </div>
      
      <p className="text-gray-600 mb-6">
        {!isLoading && `Showing ${filteredPharmacies.length} pharmacies near you`}
      </p>
      
      <div className="space-y-4">
        {isLoading ? (
          Array(3).fill(0).map((_, index) => (
            <div key={index} className="bg-white rounded-lg shadow-md p-4 border border-gray-100">
              <div className="flex flex-col md:flex-row">
                <Skeleton className="h-40 w-full md:w-60 md:h-auto rounded-md" />
                <div className="flex-grow p-4">
                  <Skeleton className="h-6 w-3/4 mb-2" />
                  <Skeleton className="h-4 w-2/4 mb-4" />
                  <div className="space-y-2">
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-full" />
                  </div>
                </div>
              </div>
            </div>
          ))
        ) : filteredPharmacies.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-xl text-gray-600">No pharmacies found matching your search.</p>
            <p className="mt-2 text-gray-500">Try adjusting your search term or resetting filters.</p>
          </div>
        ) : (
          filteredPharmacies.map(pharmacy => (
            <div key={pharmacy.id} className="bg-white rounded-lg shadow-md border border-gray-100 hover:shadow-lg transition-shadow duration-300">
              <div className="flex flex-col md:flex-row">
                <div className="md:w-60 h-48 md:h-auto">
                  <img 
                    src={pharmacy.image || 'https://via.placeholder.com/300x200?text=No+Image'} 
                    alt={pharmacy.name} 
                    className="w-full h-full object-cover object-center rounded-t-lg md:rounded-l-lg md:rounded-tr-none"
                  />
                </div>
                
                <div className="flex-grow p-4">
                  <div className="flex flex-col md:flex-row md:justify-between md:items-start">
                    <div>
                      <h3 className="text-xl font-semibold mb-1 text-gray-800">{pharmacy.name}</h3>
                      <div className="flex items-center mb-2">
                        {Array(5).fill(0).map((_, i) => (
                          <Star 
                            key={i} 
                            className={`h-4 w-4 ${i < Math.floor(pharmacy.rating) ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
                          />
                        ))}
                        <span className="ml-2 text-sm text-gray-600">{pharmacy.rating}</span>
                      </div>
                    </div>
                    
                    <div className="mt-2 md:mt-0">
                      <Badge className={pharmacy.isOpen ? 'bg-medigreen-500' : 'bg-gray-500'}>
                        {pharmacy.isOpen ? 'Open Now' : 'Closed'}
                      </Badge>
                      <p className="text-sm text-gray-500 mt-1">{pharmacy.medicineCount} medicines available</p>
                    </div>
                  </div>
                  
                  <div className="space-y-2 mt-4">
                    <div className="flex items-center">
                      <MapPin className="h-4 w-4 text-gray-500 mr-2" />
                      <p className="text-gray-600 text-sm">{pharmacy.address}</p>
                      <Badge variant="outline" className="ml-2 text-xs">
                        {pharmacy.distance} mi away
                      </Badge>
                    </div>
                    
                    <div className="flex items-center">
                      <Phone className="h-4 w-4 text-gray-500 mr-2" />
                      <p className="text-gray-600 text-sm">{pharmacy.phone}</p>
                    </div>
                    
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 text-gray-500 mr-2" />
                      <p className="text-gray-600 text-sm">{pharmacy.hours}</p>
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center mt-6">
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-medibleu-500 text-medibleu-500 hover:bg-medibleu-50"
                      onClick={() => togglePharmacyDetails(pharmacy.id)}
                    >
                      {selectedPharmacy === pharmacy.id ? (
                        <>
                          <ChevronUp className="h-4 w-4 mr-1" />
                          Show Less
                        </>
                      ) : (
                        <>
                          <ChevronDown className="h-4 w-4 mr-1" />
                          Show More
                        </>
                      )}
                    </Button>
                    
                    <div className="space-x-2">
                      <a 
                        href={`https://www.google.com/maps/dir/?api=1&destination=${pharmacy.latitude},${pharmacy.longitude}`}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <Button 
                          size="sm"
                          variant="outline"
                          className="border-medibleu-500 text-medibleu-500 hover:bg-medibleu-50"
                        >
                          Get Directions
                        </Button>
                      </a>
                      <Button
                        size="sm"
                        asChild
                        className="bg-medibleu-500 hover:bg-medibleu-600"
                      >
                        <Link to={`/pharmacy/${pharmacy.id}`}>View Medicines</Link>
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
              
              {selectedPharmacy === pharmacy.id && (
                <div className="border-t border-gray-100 p-4">
                  <h4 className="font-semibold mb-2">About {pharmacy.name}</h4>
                  <p className="text-gray-600 text-sm mb-4">
                    {pharmacy.name} offers a wide range of pharmaceutical services including prescription filling, 
                    over-the-counter medications, health consultations, and more. The pharmacy stocks {pharmacy.medicineCount} different medicines 
                    and serves the local {pharmacy.address.split(',')[1]} community.
                  </p>
                  
                  <h4 className="font-semibold mb-2">Services</h4>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2 mb-4">
                    <Badge variant="outline" className="justify-center">Prescription Filling</Badge>
                    <Badge variant="outline" className="justify-center">Medication Review</Badge>
                    <Badge variant="outline" className="justify-center">Vaccination</Badge>
                    <Badge variant="outline" className="justify-center">Health Checkups</Badge>
                    <Badge variant="outline" className="justify-center">Home Delivery</Badge>
                    <Badge variant="outline" className="justify-center">Health Consultation</Badge>
                  </div>
                  
                  <div className="bg-gray-100 rounded-md p-4 text-center">
                    <p className="text-gray-500">Interactive map would be displayed here</p>
                    <p className="text-sm text-gray-400">Coordinates: {pharmacy.latitude}, {pharmacy.longitude}</p>
                  </div>
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default Pharmacies;
