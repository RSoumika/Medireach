import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '@/contexts/CartContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from '@/hooks/use-toast';
import { Trash, ShoppingBag, ChevronLeft, IndianRupee } from 'lucide-react';

const Cart = () => {
  const { cart, updateQuantity, removeFromCart, clearCart } = useCart();
  const navigate = useNavigate();

  const handleCheckout = () => {
    if (cart.items.length === 0) {
      toast({
        title: "Cart is empty",
        description: "Please add items to your cart before checking out.",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Reservation placed",
      description: "Your medicines have been reserved for pickup.",
    });
    clearCart();
    navigate('/reservations');
  };

  const itemsByPharmacy: Record<string, typeof cart.items> = {};
  cart.items.forEach(item => {
    if (!itemsByPharmacy[item.pharmacyId]) {
      itemsByPharmacy[item.pharmacyId] = [];
    }
    itemsByPharmacy[item.pharmacyId].push(item);
  });

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Your Cart</h1>
      
      <Link to="/search" className="flex items-center text-medibleu-600 hover:text-medibleu-700 mb-6">
        <ChevronLeft className="h-4 w-4 mr-1" />
        Continue Shopping
      </Link>
      
      {cart.items.length > 0 ? (
        <div className="flex flex-col lg:flex-row gap-6">
          <div className="lg:w-2/3">
            {Object.keys(itemsByPharmacy).map(pharmacyId => {
              const pharmacyItems = itemsByPharmacy[pharmacyId];
              const pharmacyName = pharmacyItems[0]?.pharmacyName || 'Pharmacy';
              
              return (
                <div key={pharmacyId} className="mb-6 bg-white rounded-lg shadow-md overflow-hidden">
                  <div className="bg-gray-50 px-6 py-4 border-b">
                    <h2 className="text-lg font-semibold text-gray-800">
                      {pharmacyName}
                    </h2>
                  </div>
                  
                  <div className="divide-y divide-gray-100">
                    {pharmacyItems.map(item => (
                      <div key={item.medicine.id} className="flex flex-col sm:flex-row items-center p-4 sm:p-6">
                        <div className="sm:w-24 h-24 sm:h-24 flex-shrink-0 mb-4 sm:mb-0">
                          <img 
                            src={item.medicine.image || 'https://via.placeholder.com/100?text=Medicine'} 
                            alt={item.medicine.name}
                            className="w-full h-full object-cover rounded-md"
                          />
                        </div>
                        
                        <div className="sm:ml-6 flex-grow">
                          <h3 className="text-base font-medium text-gray-900">{item.medicine.name}</h3>
                          <p className="text-sm text-gray-500">{item.medicine.dosage}</p>
                        </div>
                        
                        <div className="flex items-center mt-4 sm:mt-0">
                          <div className="flex items-center mr-6">
                            <button
                              className="w-8 h-8 border border-gray-300 rounded-l-md flex items-center justify-center"
                              onClick={() => updateQuantity(item.medicine.id, Math.max(1, item.quantity - 1))}
                            >
                              -
                            </button>
                            <Input
                              type="number"
                              value={item.quantity}
                              onChange={(e) => {
                                const value = parseInt(e.target.value);
                                if (!isNaN(value) && value >= 1) {
                                  updateQuantity(item.medicine.id, value);
                                }
                              }}
                              min="1"
                              className="w-12 h-8 text-center border-t border-b border-gray-300 rounded-none"
                            />
                            <button
                              className="w-8 h-8 border border-gray-300 rounded-r-md flex items-center justify-center"
                              onClick={() => updateQuantity(item.medicine.id, item.quantity + 1)}
                            >
                              +
                            </button>
                          </div>
                          
                          <div className="text-right min-w-[80px]">
                            <p className="text-base font-medium text-gray-900 flex items-center justify-end">
                              <IndianRupee className="h-4 w-4 mr-1" />
                              {(item.medicine.price * item.quantity).toFixed(2)}
                            </p>
                            <p className="text-xs text-gray-500 flex items-center justify-end">
                              <IndianRupee className="h-3 w-3 mr-1" />
                              {item.medicine.price.toFixed(2)} each
                            </p>
                          </div>
                          
                          <button
                            onClick={() => removeFromCart(item.medicine.id)}
                            className="ml-4 text-gray-400 hover:text-red-500"
                          >
                            <Trash className="h-5 w-5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
          
          <div className="lg:w-1/3">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-lg font-semibold text-gray-800 mb-4">Order Summary</h2>
              
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <p className="text-gray-600">Subtotal</p>
                  <p className="font-medium flex items-center">
                    <IndianRupee className="h-4 w-4 mr-1" />
                    {cart.total.toFixed(2)}
                  </p>
                </div>
                <div className="flex justify-between items-center">
                  <p className="text-gray-600">Processing Fee</p>
                  <p className="font-medium flex items-center">
                    <IndianRupee className="h-4 w-4 mr-1" />
                    0.00
                  </p>
                </div>
                <div className="border-t border-gray-200 pt-3">
                  <div className="flex justify-between items-center">
                    <p className="text-lg font-semibold">Total</p>
                    <p className="text-lg font-semibold text-medibleu-600 flex items-center">
                      <IndianRupee className="h-4 w-4 mr-1" />
                      {cart.total.toFixed(2)}
                    </p>
                  </div>
                </div>
              </div>
              
              <Button 
                className="w-full mt-6 bg-medibleu-500 hover:bg-medibleu-600"
                onClick={handleCheckout}
              >
                <ShoppingBag className="mr-2 h-4 w-4" />
                Reserve for Pickup
              </Button>
              
              <div className="mt-4 text-center text-sm text-gray-500">
                <p>
                  Your medicines will be reserved for pickup at the selected pharmacies. You'll be notified when they're ready.
                </p>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="text-center py-12 bg-white rounded-lg shadow-md">
          <div className="inline-flex items-center justify-center w-24 h-24 bg-gray-100 rounded-full mb-6">
            <ShoppingBag className="h-12 w-12 text-gray-400" />
          </div>
          <h2 className="text-2xl font-semibold text-gray-800 mb-2">Your cart is empty</h2>
          <p className="text-gray-600 mb-6">Looks like you haven't added any medicines to your cart yet.</p>
          <Link to="/search">
            <Button className="bg-medibleu-500 hover:bg-medibleu-600">
              Browse Medicines
            </Button>
          </Link>
        </div>
      )}
    </div>
  );
};

export default Cart;
