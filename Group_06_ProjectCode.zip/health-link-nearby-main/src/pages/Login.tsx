
import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from '@/hooks/use-toast';
import MediReachLogo from '@/components/common/MediReachLogo';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      setIsLoading(true);
      await login(email, password);
      toast({
        title: "Login successful",
        description: "Welcome back to MediReach!",
      });
      navigate('/');
    } catch (error) {
      toast({
        title: "Login failed",
        description: "Invalid email or password. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleDemoLogin = async (role: 'user' | 'pharmacist' | 'admin') => {
    let email = '';
    let password = 'password';

    switch (role) {
      case 'user':
        email = 'user@example.com';
        break;
      case 'pharmacist':
        email = 'pharmacist@example.com';
        break;
      case 'admin':
        email = 'admin@example.com';
        break;
    }

    try {
      setIsLoading(true);
      await login(email, password);
      toast({
        title: "Demo login successful",
        description: `You are now logged in as a ${role}.`,
      });
      navigate('/');
    } catch (error) {
      toast({
        title: "Login failed",
        description: "Something went wrong with the demo login.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full bg-white rounded-lg shadow-md p-8">
        <div className="flex flex-col items-center mb-8">
          <MediReachLogo className="h-12 w-auto mb-2" />
          <h2 className="text-center text-3xl font-bold text-gray-900">Sign in to MediReach</h2>
          <p className="mt-2 text-center text-sm text-gray-600">
            Or{' '}
            <Link to="/register" className="font-medium text-medibleu-600 hover:text-medibleu-500">
              create a new account
            </Link>
          </p>
        </div>
        
        <form className="space-y-6" onSubmit={handleSubmit}>
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-700">
              Email address
            </label>
            <Input
              id="email"
              name="email"
              type="email"
              autoComplete="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="mt-1"
              placeholder="your@email.com"
            />
          </div>

          <div>
            <label htmlFor="password" className="block text-sm font-medium text-gray-700">
              Password
            </label>
            <Input
              id="password"
              name="password"
              type="password"
              autoComplete="current-password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="mt-1"
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <input
                id="remember-me"
                name="remember-me"
                type="checkbox"
                className="h-4 w-4 text-medibleu-600 focus:ring-medibleu-500 border-gray-300 rounded"
              />
              <label htmlFor="remember-me" className="ml-2 block text-sm text-gray-900">
                Remember me
              </label>
            </div>

            <div className="text-sm">
              <a href="#" className="font-medium text-medibleu-600 hover:text-medibleu-500">
                Forgot your password?
              </a>
            </div>
          </div>

          <div>
            <Button
              type="submit"
              className="w-full bg-medibleu-500 hover:bg-medibleu-600"
              disabled={isLoading}
            >
              {isLoading ? 'Signing in...' : 'Sign in'}
            </Button>
          </div>
        </form>

        <div className="mt-8">
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-300"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-white text-gray-500">Demo logins</span>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-1 gap-3">
            <Button
              type="button"
              variant="outline"
              className="border-medibleu-200 hover:bg-medibleu-50"
              onClick={() => handleDemoLogin('user')}
              disabled={isLoading}
            >
              Login as Patient
            </Button>
            <Button
              type="button"
              variant="outline"
              className="border-medigreen-200 hover:bg-medigreen-50"
              onClick={() => handleDemoLogin('pharmacist')}
              disabled={isLoading}
            >
              Login as Pharmacist
            </Button>
            <Button
              type="button"
              variant="outline"
              className="border-gray-300 hover:bg-gray-50"
              onClick={() => handleDemoLogin('admin')}
              disabled={isLoading}
            >
              Login as Admin
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
