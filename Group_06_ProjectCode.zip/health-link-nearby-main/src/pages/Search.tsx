import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Search as SearchIcon, Filter, IndianRupee, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { useCart } from '@/contexts/CartContext';
import { Medicine } from '@/contexts/CartContext';
import { toast } from '@/hooks/use-toast';

const dummyMedicines: (Medicine & { pharmacyId: string, pharmacyName: string, location: { lat: number, lng: number } })[] = [
  {
    id: '1',
    name: 'Paracetamol 500mg',
    price: 45,
    description: 'Pain reliever and fever reducer',
    dosage: '500mg',
    manufacturer: 'MediCorp',
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    inStock: true,
    pharmacyId: 'p1',
    pharmacyName: 'Krishna Medical Store',
    location: { lat: 16.3067, lng: 80.4365 }
  },
  {
    id: '2',
    name: 'Amoxicillin 250mg',
    price: 120,
    description: 'Antibiotic used to treat bacterial infections',
    dosage: '250mg',
    manufacturer: 'HealthCare Ltd',
    image: 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    inStock: true,
    pharmacyId: 'p2',
    pharmacyName: 'Guntur Pharmacy',
    location: { lat: 16.3088, lng: 80.4365 }
  },
  {
    id: '3',
    name: 'Ibuprofen 200mg',
    price: 85,
    description: 'Non-steroidal anti-inflammatory drug',
    dosage: '200mg',
    manufacturer: 'PharmaCorp',
    image: 'https://images.unsplash.com/photo-1585435557343-3b092031a831?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    inStock: true,
    pharmacyId: 'p1',
    pharmacyName: 'Krishna Medical Store',
    location: { lat: 16.3067, lng: 80.4365 }
  },
  {
    id: '4',
    name: 'Loratadine 10mg',
    price: 95,
    description: 'Antihistamine for allergies',
    dosage: '10mg',
    manufacturer: 'AllergyRelief Inc',
    image: 'https://images.unsplash.com/photo-1471864190281-a93a3070b6de?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    inStock: false,
    pharmacyId: 'p3',
    pharmacyName: 'Lalitha Pharmacy',
    location: { lat: 16.3075, lng: 80.4375 }
  },
  {
    id: '5',
    name: 'Metformin 500mg',
    price: 150,
    description: 'Oral diabetes medicine',
    dosage: '500mg',
    manufacturer: 'DiabetesControl Co',
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    inStock: true,
    pharmacyId: 'p2',
    pharmacyName: 'Guntur Pharmacy',
    location: { lat: 16.3088, lng: 80.4365 }
  },
  {
    id: '6',
    name: 'Aspirin 325mg',
    price: 50,
    description: 'Pain reliever and blood thinner',
    dosage: '325mg',
    manufacturer: 'HeartCare Ltd',
    image: 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    inStock: true,
    pharmacyId: 'p3',
    pharmacyName: 'Lalitha Pharmacy',
    location: { lat: 16.3075, lng: 80.4375 }
  },
  {
    id: '7',
    name: 'Simvastatin 20mg',
    price: 260,
    description: 'Lowers cholesterol and triglycerides',
    dosage: '20mg',
    manufacturer: 'CardioHealth Inc',
    image: 'https://images.unsplash.com/photo-1471864190281-a93a3070b6de?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    inStock: true,
    pharmacyId: 'p1',
    pharmacyName: 'Krishna Medical Store',
    location: { lat: 16.3067, lng: 80.4365 }
  },
  {
    id: '8',
    name: 'Omeprazole 20mg',
    price: 190,
    description: 'Reduces stomach acid production',
    dosage: '20mg',
    manufacturer: 'GutHealth Corp',
    image: 'https://images.unsplash.com/photo-1585435557343-3b092031a831?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    inStock: false,
    pharmacyId: 'p2',
    pharmacyName: 'Guntur Pharmacy',
    location: { lat: 16.3088, lng: 80.4365 }
  },
  {
    id: '9',
    name: 'Azithromycin 500mg',
    price: 280,
    description: 'Antibiotic for bacterial infections',
    dosage: '500mg',
    manufacturer: 'PharmaCorp',
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    inStock: true,
    pharmacyId: 'p3',
    pharmacyName: 'Lalitha Pharmacy',
    location: { lat: 16.3075, lng: 80.4375 }
  },
  {
    id: '10',
    name: 'Cetirizine 10mg',
    price: 75,
    description: 'Antihistamine for allergies',
    dosage: '10mg',
    manufacturer: 'AllergyRelief Inc',
    image: 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    inStock: true,
    pharmacyId: 'p1',
    pharmacyName: 'Krishna Medical Store',
    location: { lat: 16.3067, lng: 80.4365 }
  }
];

const Search = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [medicines, setMedicines] = useState<typeof dummyMedicines>([]);
  const [filteredMedicines, setFilteredMedicines] = useState<typeof dummyMedicines>([]);
  const [filters, setFilters] = useState({
    inStockOnly: false,
    sortBy: 'relevance',
    maxPrice: 50,
    manufacturer: 'all',
  });
  const [showFilters, setShowFilters] = useState(false);
  const { addToCart } = useCart();

  useEffect(() => {
    const fetchMedicines = async () => {
      await new Promise(resolve => setTimeout(resolve, 1000));
      setMedicines(dummyMedicines);
      setFilteredMedicines(dummyMedicines);
      setIsLoading(false);
    };

    fetchMedicines();
  }, []);

  useEffect(() => {
    if (!medicines.length) return;

    let results = [...medicines];
    
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      results = results.filter(medicine => 
        medicine.name.toLowerCase().includes(term) || 
        medicine.description?.toLowerCase().includes(term) ||
        medicine.manufacturer?.toLowerCase().includes(term)
      );
    }
    
    if (filters.inStockOnly) {
      results = results.filter(medicine => medicine.inStock);
    }
    
    if (filters.manufacturer !== 'all') {
      results = results.filter(medicine => medicine.manufacturer === filters.manufacturer);
    }
    
    results = results.filter(medicine => medicine.price <= filters.maxPrice);
    
    switch (filters.sortBy) {
      case 'price-low':
        results.sort((a, b) => a.price - b.price);
        break;
      case 'price-high':
        results.sort((a, b) => b.price - a.price);
        break;
      case 'name':
        results.sort((a, b) => a.name.localeCompare(b.name));
        break;
      default:
        break;
    }
    
    setFilteredMedicines(results);
  }, [searchTerm, filters, medicines]);

  const manufacturers = ['all', ...new Set(medicines.map(med => med.manufacturer || '').filter(Boolean))];

  const handleAddToCart = (medicine: Medicine, pharmacyId: string, pharmacyName: string) => {
    addToCart(medicine, 1, pharmacyId, pharmacyName);
    toast({
      title: "Added to cart",
      description: `${medicine.name} has been added to your cart.`,
    });
  };

  const handleGetDirections = (location: { lat: number, lng: number }) => {
    window.open(`https://www.google.com/maps/dir/?api=1&destination=${location.lat},${location.lng}`, '_blank');
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Find Medicines</h1>
      
      <div className="flex items-center mb-6">
        <div className="relative flex-grow">
          <Input
            type="text"
            placeholder="Search medicines by name, ingredient, or description..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 pr-4 py-2 rounded-md border border-gray-300 w-full"
          />
          <SearchIcon className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
        </div>
        <Button
          variant="outline"
          className="ml-4 border-gray-300"
          onClick={() => setShowFilters(!showFilters)}
        >
          <Filter className="h-4 w-4 mr-2" />
          Filters
        </Button>
      </div>
      
      {showFilters && (
        <div className="bg-gray-50 p-4 rounded-lg mb-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Sort by</label>
              <Select 
                value={filters.sortBy} 
                onValueChange={(value) => setFilters({...filters, sortBy: value})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="relevance">Relevance</SelectItem>
                  <SelectItem value="price-low">Price: Low to High</SelectItem>
                  <SelectItem value="price-high">Price: High to Low</SelectItem>
                  <SelectItem value="name">Name</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Manufacturer</label>
              <Select 
                value={filters.manufacturer} 
                onValueChange={(value) => setFilters({...filters, manufacturer: value})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="All manufacturers" />
                </SelectTrigger>
                <SelectContent>
                  {manufacturers.map((manufacturer, index) => (
                    <SelectItem key={index} value={manufacturer}>
                      {manufacturer === 'all' ? 'All Manufacturers' : manufacturer}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Max Price: ${filters.maxPrice}</label>
              <input
                type="range"
                min="0"
                max="100"
                value={filters.maxPrice}
                onChange={(e) => setFilters({...filters, maxPrice: parseInt(e.target.value)})}
                className="w-full"
              />
            </div>
            
            <div className="flex items-center">
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="in-stock" 
                  checked={filters.inStockOnly}
                  onCheckedChange={(checked) => 
                    setFilters({...filters, inStockOnly: checked === true})}
                />
                <label
                  htmlFor="in-stock"
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                >
                  Show only in-stock items
                </label>
              </div>
            </div>
          </div>
        </div>
      )}
      
      <p className="text-gray-600 mb-6">
        {!isLoading && `Showing ${filteredMedicines.length} results`}
      </p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {isLoading ? (
          Array(8).fill(0).map((_, index) => (
            <div key={index} className="bg-white rounded-lg shadow-md p-4 border border-gray-100">
              <Skeleton className="h-40 w-full mb-4" />
              <Skeleton className="h-6 w-3/4 mb-2" />
              <Skeleton className="h-4 w-2/4 mb-4" />
              <Skeleton className="h-5 w-1/4 mb-2" />
              <div className="flex justify-between mt-4">
                <Skeleton className="h-10 w-24" />
                <Skeleton className="h-10 w-24" />
              </div>
            </div>
          ))
        ) : filteredMedicines.length === 0 ? (
          <div className="col-span-full text-center py-12">
            <p className="text-xl text-gray-600">No medicines found matching your search criteria.</p>
            <p className="mt-2 text-gray-500">Try adjusting your filters or search term.</p>
          </div>
        ) : (
          filteredMedicines.map(medicine => (
            <div key={medicine.id} className="bg-white rounded-lg shadow-md p-4 border border-gray-100 hover:shadow-lg transition-shadow duration-300">
              <div className="relative mb-3 h-48">
                <img 
                  src={medicine.image} 
                  alt={medicine.name} 
                  className="w-full h-full object-cover object-center rounded-md"
                />
                {!medicine.inStock && (
                  <Badge variant="destructive" className="absolute top-2 right-2">
                    Out of Stock
                  </Badge>
                )}
              </div>
              
              <h3 className="text-lg font-semibold mb-1 text-gray-800">{medicine.name}</h3>
              <p className="text-sm text-gray-600 mb-2">{medicine.description}</p>
              <p className="text-sm text-gray-600">
                <span className="font-medium">Dosage:</span> {medicine.dosage}
              </p>
              <p className="text-sm text-gray-600 mb-4">
                <span className="font-medium">Available at:</span> {medicine.pharmacyName}
              </p>
              
              <div className="flex flex-col gap-2">
                <div className="flex justify-between items-center">
                  <p className="text-lg font-bold text-medibleu-600 flex items-center">
                    <IndianRupee className="h-4 w-4 mr-1" />
                    {medicine.price.toFixed(2)}
                  </p>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1 border-medibleu-500 text-medibleu-500 hover:bg-medibleu-50"
                    asChild
                  >
                    <Link to={`/medicine/${medicine.id}`}>Details</Link>
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1 border-medibleu-500 text-medibleu-500 hover:bg-medibleu-50"
                    onClick={() => handleGetDirections(medicine.location)}
                  >
                    <MapPin className="h-4 w-4 mr-1" />
                    Directions
                  </Button>
                </div>
                <Button
                  size="sm"
                  className="w-full bg-medibleu-500 hover:bg-medibleu-600"
                  disabled={!medicine.inStock}
                  onClick={() => handleAddToCart(medicine, medicine.pharmacyId, medicine.pharmacyName)}
                >
                  Add to Cart
                </Button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default Search;
