
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Search, MapPin } from 'lucide-react';

const Index = () => {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-medibleu-50 to-blue-100 py-20">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center">
            <div className="w-full md:w-1/2 mb-8 md:mb-0">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-medibleu-600 leading-tight">
                Find Medicines Near You in Guntur
              </h1>
              <p className="mt-6 text-lg text-gray-700 mb-8">
                MediReach connects you with nearby pharmacies in Guntur, helping you locate and reserve the medicines you need, when you need them.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link to="/search">
                  <Button className="bg-medibleu-500 hover:bg-medibleu-600 text-white px-6 py-3 rounded-md inline-flex items-center">
                    <Search className="mr-2 h-5 w-5" />
                    <span className="text-base">Find Medicines</span>
                  </Button>
                </Link>
                <Link to="/pharmacies">
                  <Button variant="outline" className="border-medibleu-500 text-medibleu-500 px-6 py-3 rounded-md inline-flex items-center">
                    <MapPin className="mr-2 h-5 w-5" />
                    <span className="text-base">Nearby Pharmacies</span>
                  </Button>
                </Link>
              </div>
            </div>
            <div className="w-full md:w-1/2 flex justify-center">
              <img 
                src="https://images.unsplash.com/photo-1583911860248-4d2be6ace4c3?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                alt="MediReach Hero" 
                className="max-w-full h-auto rounded-lg shadow-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-gray-800 mb-12">
            How MediReach Works in Guntur
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Step 1 */}
            <div className="flex flex-col items-center text-center">
              <div className="bg-medibleu-50 rounded-full p-6 mb-6">
                <Search className="h-12 w-12 text-medibleu-600" />
              </div>
              <h3 className="text-xl font-semibold mb-4">Search Medicines</h3>
              <p className="text-gray-600">
                Easily search for medicines by name or active ingredients to check availability at nearby pharmacies in Guntur.
              </p>
              <img 
                src="https://images.unsplash.com/photo-1631549916768-4119b4123a21?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                alt="Search Medicines" 
                className="mt-6 rounded-lg shadow-md w-full h-48 object-cover"
              />
            </div>
            
            {/* Step 2 */}
            <div className="flex flex-col items-center text-center">
              <div className="bg-medibleu-50 rounded-full p-6 mb-6">
                <MapPin className="h-12 w-12 text-medibleu-600" />
              </div>
              <h3 className="text-xl font-semibold mb-4">Find Nearby Pharmacies</h3>
              <p className="text-gray-600">
                Discover pharmacies in Guntur that have your medicines in stock, with real-time availability.
              </p>
              <img 
                src="https://images.unsplash.com/photo-1586015555751-63c29b4bd310?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                alt="Find Pharmacies" 
                className="mt-6 rounded-lg shadow-md w-full h-48 object-cover"
              />
            </div>
            
            {/* Step 3 */}
            <div className="flex flex-col items-center text-center">
              <div className="bg-medibleu-50 rounded-full p-6 mb-6">
                <svg className="h-12 w-12 text-medibleu-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-4">Reserve & Pickup</h3>
              <p className="text-gray-600">
                Reserve your medicines for pickup at pharmacies in Guntur and get notifications when they're ready.
              </p>
              <img 
                src="https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                alt="Reserve & Pickup" 
                className="mt-6 rounded-lg shadow-md w-full h-48 object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Featured Services */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-gray-800 mb-4">
            Our Services in Guntur
          </h2>
          <p className="text-center text-gray-600 mb-12 max-w-2xl mx-auto">
            MediReach offers a comprehensive platform for both patients and pharmacies in Guntur to connect and manage medicines efficiently.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Service 1 */}
            <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow duration-300">
              <div className="text-medibleu-500 mb-4">
                <svg className="h-10 w-10" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">Medicine Search</h3>
              <p className="text-gray-600">
                Search medicines by name or ingredients and find exactly what you need at the best pharmacy in Guntur.
              </p>
              <img 
                src="https://images.unsplash.com/photo-1584729116911-011cede49e2f?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                alt="Medicine Search" 
                className="mt-4 rounded-lg w-full h-32 object-cover"
              />
            </div>
            
            {/* Service 2 */}
            <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow duration-300">
              <div className="text-medibleu-500 mb-4">
                <svg className="h-10 w-10" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">Real-time Reservations</h3>
              <p className="text-gray-600">
                Reserve medicines ahead of time and receive notifications when they're ready for pickup at Guntur pharmacies.
              </p>
              <img 
                src="https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                alt="Real-time Reservations" 
                className="mt-4 rounded-lg w-full h-32 object-cover"
              />
            </div>
            
            {/* Service 3 */}
            <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow duration-300">
              <div className="text-medibleu-500 mb-4">
                <svg className="h-10 w-10" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m0 0L11 14h4a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v4l.586-.586z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">AI Medicine Assistant</h3>
              <p className="text-gray-600">
                Get intelligent suggestions for alternative medicines when your prescribed medicine is unavailable in Guntur.
              </p>
              <img 
                src="https://images.unsplash.com/photo-1560582861-45078880e48e?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                alt="AI Medicine Assistant" 
                className="mt-4 rounded-lg w-full h-32 object-cover"
              />
            </div>
            
            {/* Service 4 */}
            <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow duration-300">
              <div className="text-medibleu-500 mb-4">
                <svg className="h-10 w-10" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">Pharmacy Locator</h3>
              <p className="text-gray-600">
                Find the nearest pharmacies in Guntur with detailed information, opening hours, and directions.
              </p>
              <img 
                src="https://images.unsplash.com/photo-1555633514-abcee6ab92e1?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                alt="Pharmacy Locator" 
                className="mt-4 rounded-lg w-full h-32 object-cover"
              />
            </div>
            
            {/* Service 5 */}
            <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow duration-300">
              <div className="text-medibleu-500 mb-4">
                <svg className="h-10 w-10" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">Medication Management</h3>
              <p className="text-gray-600">
                Track your medication history, refills, and get reminders for pickups and dosage schedules from pharmacies in Guntur.
              </p>
              <img 
                src="https://images.unsplash.com/photo-1585435557343-3b092031a831?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                alt="Medication Management" 
                className="mt-4 rounded-lg w-full h-32 object-cover"
              />
            </div>
            
            {/* Service 6 */}
            <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow duration-300">
              <div className="text-medibleu-500 mb-4">
                <svg className="h-10 w-10" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">Real-time Updates</h3>
              <p className="text-gray-600">
                Get instant notifications about medicine availability, price changes, and reservation status from pharmacies in Guntur.
              </p>
              <img 
                src="https://images.unsplash.com/photo-1603398938378-e54eab446dde?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                alt="Real-time Updates" 
                className="mt-4 rounded-lg w-full h-32 object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-medibleu-600 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Find Your Medicines in Guntur?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Join thousands of users who save time finding and reserving their medications with MediReach in Guntur.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link to="/register">
              <Button className="bg-white hover:bg-gray-100 text-medibleu-600 px-6 py-3 rounded-md text-base">
                Sign Up Now
              </Button>
            </Link>
            <Link to="/search">
              <Button variant="outline" className="border-white text-white hover:bg-white/10 px-6 py-3 rounded-md text-base">
                Browse Medicines
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;
