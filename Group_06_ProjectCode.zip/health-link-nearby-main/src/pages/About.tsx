
import React from 'react';
import { Button } from '@/components/ui/button';
import MediReachLogo from '@/components/common/MediReachLogo';

const About = () => {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-12">
          <MediReachLogo className="h-20 w-20 mx-auto mb-6" />
          <h1 className="text-4xl font-bold text-medibleu-600 mb-4">About MediReach</h1>
          <p className="text-xl text-gray-600">
            Connecting patients with local pharmacies for better healthcare access
          </p>
        </div>

        {/* Our Mission */}
        <div className="mb-16">
          <h2 className="text-3xl font-semibold mb-6 text-gray-800">Our Mission</h2>
          <p className="text-lg text-gray-600 mb-4">
            MediReach is on a mission to revolutionize how people access pharmaceutical care. We believe that everyone should have quick and easy access to their medications, without the hassle of visiting multiple pharmacies or making unnecessary phone calls.
          </p>
          <p className="text-lg text-gray-600">
            By connecting patients directly with local pharmacies in real-time, we're building a healthcare ecosystem that saves time, reduces stress, and ultimately improves medication adherence and health outcomes.
          </p>
        </div>

        {/* How It Works */}
        <div className="bg-gray-50 rounded-xl p-8 mb-16">
          <h2 className="text-3xl font-semibold mb-8 text-center text-gray-800">How MediReach Works</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-medibleu-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <span className="text-xl font-bold text-medibleu-600">1</span>
              </div>
              <h3 className="text-xl font-medium mb-2">Search Medicines</h3>
              <p className="text-gray-600">
                Look up medications by name or ingredients to find availability near you
              </p>
            </div>

            <div className="text-center">
              <div className="bg-medibleu-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <span className="text-xl font-bold text-medibleu-600">2</span>
              </div>
              <h3 className="text-xl font-medium mb-2">Reserve & Confirm</h3>
              <p className="text-gray-600">
                Reserve your medicines at your preferred pharmacy for guaranteed availability
              </p>
            </div>

            <div className="text-center">
              <div className="bg-medibleu-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <span className="text-xl font-bold text-medibleu-600">3</span>
              </div>
              <h3 className="text-xl font-medium mb-2">Pick Up Medicines</h3>
              <p className="text-gray-600">
                Get notified when your order is ready and pick it up at your convenience
              </p>
            </div>
          </div>
        </div>

        {/* Our Team */}
        <div className="mb-16">
          <h2 className="text-3xl font-semibold mb-8 text-center text-gray-800">Our Team</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-32 h-32 rounded-full bg-gray-200 mx-auto mb-4 overflow-hidden">
                <img 
                  src="https://i.ibb.co/wdYhxzP/team-member1.jpg"
                  alt="CEO Portrait"
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-xl font-medium mb-1">Dr. James Wilson</h3>
              <p className="text-medibleu-600 mb-2">CEO & Founder</p>
              <p className="text-gray-600 text-sm">
                Former pharmacist with 15+ years of experience in healthcare innovation
              </p>
            </div>

            <div className="text-center">
              <div className="w-32 h-32 rounded-full bg-gray-200 mx-auto mb-4 overflow-hidden">
                <img 
                  src="https://i.ibb.co/LzvtJp4/team-member2.jpg"
                  alt="CTO Portrait"
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-xl font-medium mb-1">Sarah Chen</h3>
              <p className="text-medibleu-600 mb-2">CTO</p>
              <p className="text-gray-600 text-sm">
                Tech visionary with expertise in healthcare software development
              </p>
            </div>

            <div className="text-center">
              <div className="w-32 h-32 rounded-full bg-gray-200 mx-auto mb-4 overflow-hidden">
                <img 
                  src="https://i.ibb.co/qMDgc8T/team-member3.jpg"
                  alt="COO Portrait"
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-xl font-medium mb-1">Dr. Michael Rodriguez</h3>
              <p className="text-medibleu-600 mb-2">Chief Medical Officer</p>
              <p className="text-gray-600 text-sm">
                Board-certified physician dedicated to improving medication access
              </p>
            </div>
          </div>
        </div>

        {/* For Pharmacies */}
        <div className="bg-medibleu-600 text-white rounded-xl p-8 mb-16">
          <h2 className="text-3xl font-semibold mb-6 text-center">For Pharmacies</h2>
          <p className="text-lg mb-8 text-center max-w-2xl mx-auto">
            Are you a pharmacy looking to expand your reach and streamline your operations? Join the MediReach network to connect with more patients and manage your inventory efficiently.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white/10 rounded-lg p-6">
              <h3 className="text-xl font-medium mb-3">Benefits for Pharmacies</h3>
              <ul className="space-y-2">
                <li className="flex items-center">
                  <svg className="h-5 w-5 mr-2 text-medigreen-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  Increase visibility to local patients
                </li>
                <li className="flex items-center">
                  <svg className="h-5 w-5 mr-2 text-medigreen-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  Streamline inventory management
                </li>
                <li className="flex items-center">
                  <svg className="h-5 w-5 mr-2 text-medigreen-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  Get real-time analytics and insights
                </li>
                <li className="flex items-center">
                  <svg className="h-5 w-5 mr-2 text-medigreen-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  Reduce phone call interruptions
                </li>
              </ul>
            </div>
            
            <div className="bg-white/10 rounded-lg p-6">
              <h3 className="text-xl font-medium mb-3">How to Join</h3>
              <p className="mb-6">
                Joining MediReach is simple. Register as a pharmacy, complete your profile, and our team will verify your information within 48 hours.
              </p>
              <Button className="w-full bg-white hover:bg-gray-100 text-medibleu-600">
                Register Your Pharmacy
              </Button>
            </div>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="mb-16">
          <h2 className="text-3xl font-semibold mb-8 text-center text-gray-800">Frequently Asked Questions</h2>
          
          <div className="space-y-6">
            <div>
              <h3 className="text-xl font-medium mb-2 text-gray-800">Is MediReach free to use?</h3>
              <p className="text-gray-600">
                Yes, MediReach is completely free for patients to use. We generate revenue through partnerships with pharmacies, not by charging users.
              </p>
            </div>
            
            <div>
              <h3 className="text-xl font-medium mb-2 text-gray-800">How accurate is the inventory information?</h3>
              <p className="text-gray-600">
                Pharmacy inventory on MediReach is updated in real-time through direct integration with pharmacy management systems, ensuring high accuracy.
              </p>
            </div>
            
            <div>
              <h3 className="text-xl font-medium mb-2 text-gray-800">Can I use MediReach for prescription medications?</h3>
              <p className="text-gray-600">
                Yes, MediReach works with both over-the-counter and prescription medications. For prescriptions, you'll need to show your valid prescription during pickup.
              </p>
            </div>
            
            <div>
              <h3 className="text-xl font-medium mb-2 text-gray-800">How do I cancel a reservation?</h3>
              <p className="text-gray-600">
                You can cancel a reservation at any time before pickup through your account's "My Reservations" section. There are no cancellation fees.
              </p>
            </div>
          </div>
        </div>

        {/* Contact Section */}
        <div className="text-center mb-16">
          <h2 className="text-3xl font-semibold mb-6 text-gray-800">Get in Touch</h2>
          <p className="text-lg text-gray-600 mb-8">
            Have questions or feedback? We'd love to hear from you!
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <div className="bg-gray-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <svg className="h-8 w-8 text-medibleu-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
              </div>
              <h3 className="text-lg font-medium mb-2">Email Us</h3>
              <p className="text-gray-600">support@medireach.com</p>
            </div>
            
            <div>
              <div className="bg-gray-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <svg className="h-8 w-8 text-medibleu-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                </svg>
              </div>
              <h3 className="text-lg font-medium mb-2">Call Us</h3>
              <p className="text-gray-600">(123) 456-7890</p>
            </div>
            
            <div>
              <div className="bg-gray-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <svg className="h-8 w-8 text-medibleu-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
              </div>
              <h3 className="text-lg font-medium mb-2">Visit Us</h3>
              <p className="text-gray-600">123 Health Street, Suite 456<br />San Francisco, CA 94103</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
