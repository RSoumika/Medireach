
import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
} from 'recharts';
import { Calendar, Home, Package, Settings, Users, ShoppingBag, AlertTriangle } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';

// Sample data for charts
const salesData = [
  { name: 'Mon', sales: 1200, reservations: 4 },
  { name: 'Tue', sales: 1900, reservations: 7 },
  { name: 'Wed', sales: 2100, reservations: 9 },
  { name: 'Thu', sales: 2400, reservations: 12 },
  { name: 'Fri', sales: 1800, reservations: 8 },
  { name: 'Sat', sales: 2800, reservations: 14 },
  { name: 'Sun', sales: 2000, reservations: 10 },
];

const stockData = [
  { name: 'Paracetamol', stock: 150, threshold: 50 },
  { name: 'Amoxicillin', stock: 80, threshold: 30 },
  { name: 'Ibuprofen', stock: 45, threshold: 40 },
  { name: 'Aspirin', stock: 200, threshold: 75 },
  { name: 'Loratadine', stock: 60, threshold: 25 },
];

// Sample data for pending reservations
const pendingReservations = [
  {
    id: 'res001',
    customerName: 'John Doe',
    items: [
      { name: 'Paracetamol 500mg', quantity: 2 },
      { name: 'Ibuprofen 200mg', quantity: 1 },
    ],
    total: 18.73,
    createdAt: new Date(Date.now() - 4800000), // 80 min ago
  },
  {
    id: 'res002',
    customerName: 'Jane Smith',
    items: [
      { name: 'Amoxicillin 250mg', quantity: 1 },
    ],
    total: 12.50,
    createdAt: new Date(Date.now() - 1800000), // 30 min ago
  },
  {
    id: 'res003',
    customerName: 'Mike Johnson',
    items: [
      { name: 'Aspirin 325mg', quantity: 1 },
      { name: 'Simvastatin 20mg', quantity: 1 },
    ],
    total: 30.49,
    createdAt: new Date(Date.now() - 600000), // 10 min ago
  },
];

// Sample low stock alerts
const lowStockItems = [
  {
    id: 'med1',
    name: 'Ibuprofen 200mg',
    currentStock: 45,
    threshold: 40,
    status: 'warning',
  },
  {
    id: 'med2',
    name: 'Metformin 500mg',
    currentStock: 12,
    threshold: 25,
    status: 'critical',
  },
  {
    id: 'med3',
    name: 'Amlodipine 5mg',
    currentStock: 8,
    threshold: 20,
    status: 'critical',
  },
];

// Format date for display
const formatDate = (date: Date) => {
  return new Intl.DateTimeFormat('en-US', {
    hour: 'numeric',
    minute: 'numeric',
    hour12: true,
  }).format(date);
};

// Calculate time difference and format as "X minutes ago"
const getTimeAgo = (date: Date) => {
  const diff = Date.now() - date.getTime();
  const minutes = Math.floor(diff / 60000);
  
  if (minutes < 1) return 'Just now';
  if (minutes === 1) return '1 minute ago';
  if (minutes < 60) return `${minutes} minutes ago`;
  
  const hours = Math.floor(minutes / 60);
  if (hours === 1) return '1 hour ago';
  if (hours < 24) return `${hours} hours ago`;
  
  const days = Math.floor(hours / 24);
  if (days === 1) return '1 day ago';
  return `${days} days ago`;
};

const PharmacyDashboard = () => {
  const { user } = useAuth();
  const [isLoading] = useState(false);

  const handleMarkAsReady = (reservationId: string) => {
    // In a real app, this would call an API
    toast({
      title: "Reservation marked as ready",
      description: `Reservation #${reservationId} has been marked as ready for pickup.`,
    });
  };

  const handleReorderStock = (itemName: string) => {
    // In a real app, this would initiate a reorder process
    toast({
      title: "Reorder initiated",
      description: `Reorder request for ${itemName} has been submitted.`,
    });
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Pharmacy Dashboard</h1>
          <p className="text-gray-600 mt-1">Welcome back, {user?.name || 'Pharmacist'}</p>
        </div>
        <div className="mt-4 md:mt-0">
          <Button className="bg-medibleu-500 hover:bg-medibleu-600">
            <Package className="mr-2 h-4 w-4" /> Add New Inventory
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Today's Sales</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$2,845.50</div>
            <p className="text-xs text-green-500 flex items-center mt-1">
              +12.5% from yesterday
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Pending Reservations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">7</div>
            <p className="text-xs text-yellow-500 flex items-center mt-1">
              3 require immediate attention
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Stock Items</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">248</div>
            <p className="text-xs text-red-500 flex items-center mt-1">
              5 low stock alerts
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Customer Visits</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">54</div>
            <p className="text-xs text-green-500 flex items-center mt-1">
              +8.2% from last week
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-8">
        <TabsList className="grid grid-cols-2 md:grid-cols-5 gap-2">
          <TabsTrigger value="overview" className="flex items-center">
            <Home className="mr-2 h-4 w-4" /> Overview
          </TabsTrigger>
          <TabsTrigger value="reservations" className="flex items-center">
            <ShoppingBag className="mr-2 h-4 w-4" /> Reservations
          </TabsTrigger>
          <TabsTrigger value="inventory" className="flex items-center">
            <Package className="mr-2 h-4 w-4" /> Inventory
          </TabsTrigger>
          <TabsTrigger value="customers" className="flex items-center">
            <Users className="mr-2 h-4 w-4" /> Customers
          </TabsTrigger>
          <TabsTrigger value="settings" className="flex items-center">
            <Settings className="mr-2 h-4 w-4" /> Settings
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-8">
          {/* Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <Card>
              <CardHeader>
                <CardTitle>Weekly Sales</CardTitle>
                <CardDescription>Sales and reservations for the past week</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={salesData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis yAxisId="left" orientation="left" stroke="#8884d8" />
                      <YAxis yAxisId="right" orientation="right" stroke="#82ca9d" />
                      <Tooltip />
                      <Legend />
                      <Bar yAxisId="left" dataKey="sales" fill="#8884d8" name="Sales ($)" />
                      <Bar yAxisId="right" dataKey="reservations" fill="#82ca9d" name="Reservations" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Inventory Levels</CardTitle>
                <CardDescription>Current stock vs. minimum threshold</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={stockData} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" />
                      <YAxis dataKey="name" type="category" width={100} />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="stock" fill="#8884d8" name="Current Stock" />
                      <Bar dataKey="threshold" fill="#FF8042" name="Minimum Threshold" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Low Stock Alerts */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <AlertTriangle className="mr-2 h-5 w-5 text-yellow-500" />
                Low Stock Alerts
              </CardTitle>
              <CardDescription>Items that need to be restocked soon</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map(i => (
                    <div key={i} className="flex justify-between items-center">
                      <Skeleton className="h-6 w-1/3" />
                      <Skeleton className="h-6 w-20" />
                    </div>
                  ))}
                </div>
              ) : (
                <div className="divide-y">
                  {lowStockItems.map(item => (
                    <div key={item.id} className="py-3 flex justify-between items-center">
                      <div>
                        <p className="font-medium">{item.name}</p>
                        <div className="flex items-center mt-1">
                          <Badge className={item.status === 'critical' ? 'bg-red-500' : 'bg-yellow-500'}>
                            {item.status === 'critical' ? 'Critical' : 'Warning'}
                          </Badge>
                          <span className="text-sm text-gray-500 ml-2">
                            {item.currentStock} / {item.threshold} units
                          </span>
                        </div>
                      </div>
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => handleReorderStock(item.name)}
                      >
                        Reorder
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
            <CardFooter className="justify-end">
              <Button variant="outline">View All Inventory</Button>
            </CardFooter>
          </Card>

          {/* Pending Reservations */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Calendar className="mr-2 h-5 w-5 text-medibleu-500" />
                Recent Reservations
              </CardTitle>
              <CardDescription>Reservations waiting for processing</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map(i => (
                    <div key={i} className="flex flex-col space-y-3">
                      <Skeleton className="h-6 w-1/3" />
                      <Skeleton className="h-4 w-1/2" />
                      <Skeleton className="h-4 w-1/4" />
                      <div className="flex justify-between">
                        <Skeleton className="h-6 w-20" />
                        <Skeleton className="h-6 w-20" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="space-y-6">
                  {pendingReservations.map(reservation => (
                    <div key={reservation.id} className="border-b pb-4 last:border-b-0 last:pb-0">
                      <div className="flex justify-between">
                        <p className="font-medium">
                          {reservation.customerName}
                        </p>
                        <Badge className="bg-yellow-500">Pending</Badge>
                      </div>
                      <p className="text-sm text-gray-500 mt-1">
                        Order #{reservation.id} - {getTimeAgo(reservation.createdAt)}
                      </p>
                      <ul className="mt-2">
                        {reservation.items.map((item, idx) => (
                          <li key={idx} className="text-sm">
                            {item.quantity}x {item.name}
                          </li>
                        ))}
                      </ul>
                      <div className="flex justify-between mt-3 items-center">
                        <p className="font-medium text-medibleu-600">
                          ${reservation.total.toFixed(2)}
                        </p>
                        <Button 
                          size="sm" 
                          className="bg-medigreen-500 hover:bg-medigreen-600"
                          onClick={() => handleMarkAsReady(reservation.id)}
                        >
                          Mark as Ready
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
            <CardFooter className="justify-end">
              <Button variant="outline">View All Reservations</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="reservations" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Reservations Management</CardTitle>
              <CardDescription>View and manage all customer reservations</CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <p className="text-center text-gray-500 py-12">
                Detailed reservations management interface will be available here.
                <br />
                (Coming in the next update)
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="inventory" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Inventory Management</CardTitle>
              <CardDescription>Add, edit, and manage your pharmacy's inventory</CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <p className="text-center text-gray-500 py-12">
                Detailed inventory management interface will be available here.
                <br />
                (Coming in the next update)
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="customers" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Customer Management</CardTitle>
              <CardDescription>View and manage customer information</CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <p className="text-center text-gray-500 py-12">
                Customer management interface will be available here.
                <br />
                (Coming in the next update)
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Pharmacy Settings</CardTitle>
              <CardDescription>Manage your pharmacy profile and preferences</CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <p className="text-center text-gray-500 py-12">
                Pharmacy settings interface will be available here.
                <br />
                (Coming in the next update)
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default PharmacyDashboard;
