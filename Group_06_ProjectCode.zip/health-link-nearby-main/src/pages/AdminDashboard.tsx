
import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
} from 'recharts';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';
import { 
  Home, 
  Users, 
  Store, 
  PackageCheck, 
  Settings, 
  CheckSquare, 
  ShoppingBag,
  AlertTriangle
} from 'lucide-react';

// Sample data for charts
const monthlyData = [
  { name: 'Jan', reservations: 400, sales: 24000 },
  { name: 'Feb', reservations: 300, sales: 18000 },
  { name: 'Mar', reservations: 500, sales: 30000 },
  { name: 'Apr', reservations: 450, sales: 27000 },
  { name: 'May', reservations: 470, sales: 28200 },
  { name: 'Jun', reservations: 600, sales: 36000 },
  { name: 'Jul', reservations: 650, sales: 39000 },
];

const topPharmaciesData = [
  { name: 'MedPlus Pharmacy', value: 500 },
  { name: 'City Drugstore', value: 300 },
  { name: 'HealthMart', value: 400 },
  { name: 'QuickRx Pharmacy', value: 200 },
  { name: 'Family Care Pharmacy', value: 300 },
];

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

// Sample data for pending pharmacy approvals
const pendingPharmacies = [
  {
    id: 'pharm001',
    name: 'Wellness Pharmacy',
    address: '123 Health Street, Medville',
    phone: '(555) 123-4567',
    owner: 'Dr. Sarah Johnson',
    appliedAt: new Date(Date.now() - 259200000), // 3 days ago
  },
  {
    id: 'pharm002',
    name: 'MediCare Plus',
    address: '456 Care Avenue, Welltown',
    phone: '(555) 987-6543',
    owner: 'Dr. Robert Chen',
    appliedAt: new Date(Date.now() - 86400000), // 1 day ago
  },
  {
    id: 'pharm003',
    name: 'Green Cross Pharmacy',
    address: '789 Healing Blvd, Cureborough',
    phone: '(555) 456-7890',
    owner: 'Dr. Emily Martinez',
    appliedAt: new Date(Date.now() - 43200000), // 12 hours ago
  },
];

const systemAlerts = [
  {
    id: 'alert001',
    type: 'critical',
    message: 'Server load at 95% capacity',
    timestamp: new Date(Date.now() - 900000), // 15 min ago
  },
  {
    id: 'alert002',
    type: 'warning',
    message: 'Stock synchronization delay for 3 pharmacies',
    timestamp: new Date(Date.now() - 3600000), // 1 hour ago
  },
  {
    id: 'alert003',
    type: 'info',
    message: 'System maintenance scheduled for tomorrow at 2 AM',
    timestamp: new Date(Date.now() - 86400000), // 1 day ago
  },
];

// Format date for display
const formatDate = (date: Date) => {
  return new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  }).format(date);
};

// Calculate time difference and format as "X time ago"
const getTimeAgo = (date: Date) => {
  const diff = Date.now() - date.getTime();
  const minutes = Math.floor(diff / 60000);
  
  if (minutes < 1) return 'Just now';
  if (minutes === 1) return '1 minute ago';
  if (minutes < 60) return `${minutes} minutes ago`;
  
  const hours = Math.floor(minutes / 60);
  if (hours === 1) return '1 hour ago';
  if (hours < 24) return `${hours} hours ago`;
  
  const days = Math.floor(hours / 24);
  if (days === 1) return '1 day ago';
  return `${days} days ago`;
};

const AdminDashboard = () => {
  const { user } = useAuth();
  const [isLoading] = useState(false);

  const handleApprovePharmacy = (pharmacyId: string, pharmacyName: string) => {
    toast({
      title: "Pharmacy approved",
      description: `${pharmacyName} has been approved and is now active.`,
    });
  };

  const handleDenyPharmacy = (pharmacyId: string, pharmacyName: string) => {
    toast({
      title: "Pharmacy denied",
      description: `${pharmacyName}'s application has been denied.`,
      variant: "destructive",
    });
  };

  const handleDismissAlert = (alertId: string) => {
    toast({
      title: "Alert dismissed",
      description: "The alert has been acknowledged and dismissed.",
    });
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Admin Dashboard</h1>
          <p className="text-gray-600 mt-1">Welcome back, {user?.name || 'Admin'}</p>
        </div>
        <div className="mt-4 md:mt-0">
          <Button className="bg-medibleu-500 hover:bg-medibleu-600">
            <Users className="mr-2 h-4 w-4" /> Manage Users
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Total Users</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">2,845</div>
            <p className="text-xs text-green-500 flex items-center mt-1">
              +12.5% from last month
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Active Pharmacies</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">128</div>
            <p className="text-xs text-medigreen-500 flex items-center mt-1">
              3 pending approval
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Monthly Reservations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">4,721</div>
            <p className="text-xs text-medibleu-500 flex items-center mt-1">
              96% completion rate
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Total Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$283,491</div>
            <p className="text-xs text-green-500 flex items-center mt-1">
              +8.2% from last month
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-8">
        <TabsList className="grid grid-cols-2 md:grid-cols-5 gap-2">
          <TabsTrigger value="overview" className="flex items-center">
            <Home className="mr-2 h-4 w-4" /> Overview
          </TabsTrigger>
          <TabsTrigger value="users" className="flex items-center">
            <Users className="mr-2 h-4 w-4" /> Users
          </TabsTrigger>
          <TabsTrigger value="pharmacies" className="flex items-center">
            <Store className="mr-2 h-4 w-4" /> Pharmacies
          </TabsTrigger>
          <TabsTrigger value="medicines" className="flex items-center">
            <PackageCheck className="mr-2 h-4 w-4" /> Medicines
          </TabsTrigger>
          <TabsTrigger value="settings" className="flex items-center">
            <Settings className="mr-2 h-4 w-4" /> Settings
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-8">
          {/* Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <Card>
              <CardHeader>
                <CardTitle>Monthly Overview</CardTitle>
                <CardDescription>Reservations and sales for the past 6 months</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={monthlyData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis yAxisId="left" orientation="left" stroke="#8884d8" />
                      <YAxis yAxisId="right" orientation="right" stroke="#82ca9d" />
                      <Tooltip />
                      <Legend />
                      <Line 
                        yAxisId="left" 
                        type="monotone" 
                        dataKey="reservations" 
                        stroke="#8884d8" 
                        name="Reservations" 
                      />
                      <Line 
                        yAxisId="right" 
                        type="monotone" 
                        dataKey="sales" 
                        stroke="#82ca9d" 
                        name="Sales ($)" 
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Top Performing Pharmacies</CardTitle>
                <CardDescription>By number of reservations processed</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={topPharmaciesData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {topPharmaciesData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* System Alerts */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <AlertTriangle className="mr-2 h-5 w-5 text-yellow-500" />
                System Alerts
              </CardTitle>
              <CardDescription>Critical alerts that need attention</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map(i => (
                    <div key={i} className="flex justify-between items-center">
                      <Skeleton className="h-6 w-2/3" />
                      <Skeleton className="h-6 w-20" />
                    </div>
                  ))}
                </div>
              ) : (
                <div className="divide-y">
                  {systemAlerts.map(alert => (
                    <div key={alert.id} className="py-3 flex justify-between items-center">
                      <div>
                        <div className="flex items-center">
                          <Badge 
                            className={
                              alert.type === 'critical' ? 'bg-red-500' : 
                              alert.type === 'warning' ? 'bg-yellow-500' : 
                              'bg-blue-500'
                            }
                          >
                            {alert.type.charAt(0).toUpperCase() + alert.type.slice(1)}
                          </Badge>
                          <span className="ml-2 text-sm text-gray-500">
                            {getTimeAgo(alert.timestamp)}
                          </span>
                        </div>
                        <p className="mt-1 font-medium">{alert.message}</p>
                      </div>
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => handleDismissAlert(alert.id)}
                      >
                        Dismiss
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
            <CardFooter className="justify-end">
              <Button variant="outline">View All Alerts</Button>
            </CardFooter>
          </Card>

          {/* Pharmacy Approval Requests */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Store className="mr-2 h-5 w-5 text-medibleu-500" />
                Pending Pharmacy Approvals
              </CardTitle>
              <CardDescription>New pharmacy registration requests</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map(i => (
                    <div key={i} className="flex flex-col space-y-3">
                      <Skeleton className="h-6 w-1/3" />
                      <Skeleton className="h-4 w-1/2" />
                      <Skeleton className="h-4 w-1/4" />
                      <div className="flex justify-between">
                        <Skeleton className="h-6 w-20" />
                        <Skeleton className="h-6 w-20" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="space-y-6">
                  {pendingPharmacies.map(pharmacy => (
                    <div key={pharmacy.id} className="border-b pb-4 last:border-b-0 last:pb-0">
                      <div className="flex justify-between">
                        <p className="font-medium">
                          {pharmacy.name}
                        </p>
                        <Badge className="bg-yellow-500">Pending</Badge>
                      </div>
                      <div className="mt-2 space-y-1 text-sm text-gray-600">
                        <p>Owner: {pharmacy.owner}</p>
                        <p>Address: {pharmacy.address}</p>
                        <p>Phone: {pharmacy.phone}</p>
                        <p>Applied: {formatDate(pharmacy.appliedAt)}</p>
                      </div>
                      <div className="flex justify-end mt-3 space-x-2">
                        <Button 
                          size="sm" 
                          variant="outline"
                          className="border-red-500 text-red-500 hover:bg-red-50"
                          onClick={() => handleDenyPharmacy(pharmacy.id, pharmacy.name)}
                        >
                          Deny
                        </Button>
                        <Button 
                          size="sm" 
                          className="bg-medigreen-500 hover:bg-medigreen-600"
                          onClick={() => handleApprovePharmacy(pharmacy.id, pharmacy.name)}
                        >
                          Approve
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
            <CardFooter className="justify-end">
              <Button variant="outline">View All Requests</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="users" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>User Management</CardTitle>
              <CardDescription>View and manage all users</CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <p className="text-center text-gray-500 py-12">
                Detailed user management interface will be available here.
                <br />
                (Coming in the next update)
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="pharmacies" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Pharmacy Management</CardTitle>
              <CardDescription>View and manage all pharmacies</CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <p className="text-center text-gray-500 py-12">
                Detailed pharmacy management interface will be available here.
                <br />
                (Coming in the next update)
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="medicines" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Medicine Management</CardTitle>
              <CardDescription>View and manage all medicines</CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <p className="text-center text-gray-500 py-12">
                Medicine management interface will be available here.
                <br />
                (Coming in the next update)
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Platform Settings</CardTitle>
              <CardDescription>Configure platform settings and permissions</CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <p className="text-center text-gray-500 py-12">
                Platform settings interface will be available here.
                <br />
                (Coming in the next update)
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AdminDashboard;
