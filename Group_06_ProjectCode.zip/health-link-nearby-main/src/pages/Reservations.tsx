
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { toast } from '@/hooks/use-toast';
import { Calendar, MapPin, Phone, AlertCircle, CheckCircle, XCircle, Clock } from 'lucide-react';

// Define reservation types
interface Medicine {
  id: string;
  name: string;
  dosage: string;
  quantity: number;
  price: number;
}

interface Reservation {
  id: string;
  pharmacyId: string;
  pharmacyName: string;
  pharmacyAddress: string;
  pharmacyPhone: string;
  status: 'pending' | 'ready' | 'completed' | 'cancelled';
  createdAt: Date;
  readyAt?: Date;
  completedAt?: Date;
  cancelledAt?: Date;
  items: Medicine[];
  total: number;
}

// Dummy data for reservations
const dummyReservations: Reservation[] = [
  {
    id: 'res1',
    pharmacyId: 'p1',
    pharmacyName: 'MedPlus Pharmacy',
    pharmacyAddress: '123 Main Street, Cityville',
    pharmacyPhone: '(555) 123-4567',
    status: 'ready',
    createdAt: new Date(Date.now() - 86400000), // 1 day ago
    readyAt: new Date(Date.now() - 3600000), // 1 hour ago
    items: [
      {
        id: '1',
        name: 'Paracetamol 500mg',
        dosage: '500mg',
        quantity: 2,
        price: 5.99
      },
      {
        id: '3',
        name: 'Ibuprofen 200mg',
        dosage: '200mg',
        quantity: 1,
        price: 6.75
      }
    ],
    total: 18.73
  },
  {
    id: 'res2',
    pharmacyId: 'p2',
    pharmacyName: 'City Drugstore',
    pharmacyAddress: '456 Oak Avenue, Townsville',
    pharmacyPhone: '(555) 987-6543',
    status: 'pending',
    createdAt: new Date(Date.now() - 3600000), // 1 hour ago
    items: [
      {
        id: '2',
        name: 'Amoxicillin 250mg',
        dosage: '250mg',
        quantity: 1,
        price: 12.50
      }
    ],
    total: 12.50
  },
  {
    id: 'res3',
    pharmacyId: 'p3',
    pharmacyName: 'HealthMart',
    pharmacyAddress: '789 Pine Road, Villageton',
    pharmacyPhone: '(555) 456-7890',
    status: 'completed',
    createdAt: new Date(Date.now() - 604800000), // 7 days ago
    readyAt: new Date(Date.now() - 518400000), // 6 days ago
    completedAt: new Date(Date.now() - 432000000), // 5 days ago
    items: [
      {
        id: '6',
        name: 'Aspirin 325mg',
        dosage: '325mg',
        quantity: 1,
        price: 4.50
      },
      {
        id: '7',
        name: 'Simvastatin 20mg',
        dosage: '20mg',
        quantity: 1,
        price: 25.99
      }
    ],
    total: 30.49
  },
  {
    id: 'res4',
    pharmacyId: 'p1',
    pharmacyName: 'MedPlus Pharmacy',
    pharmacyAddress: '123 Main Street, Cityville',
    pharmacyPhone: '(555) 123-4567',
    status: 'cancelled',
    createdAt: new Date(Date.now() - 1209600000), // 14 days ago
    cancelledAt: new Date(Date.now() - 1123200000), // 13 days ago
    items: [
      {
        id: '5',
        name: 'Metformin 500mg',
        dosage: '500mg',
        quantity: 1,
        price: 15.30
      }
    ],
    total: 15.30
  }
];

const Reservations = () => {
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('all');

  // Load reservations (simulated API call)
  useEffect(() => {
    const fetchReservations = async () => {
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      setReservations(dummyReservations);
      setIsLoading(false);
    };

    fetchReservations();
  }, []);

  // Filter reservations based on active tab
  const filteredReservations = reservations.filter(reservation => {
    if (activeTab === 'all') return true;
    return reservation.status === activeTab;
  });

  // Handle reservation actions
  const handleCancelReservation = (reservationId: string) => {
    // In a real app, this would be an API call
    setReservations(prevReservations => 
      prevReservations.map(res => {
        if (res.id === reservationId) {
          return {
            ...res,
            status: 'cancelled',
            cancelledAt: new Date()
          };
        }
        return res;
      })
    );
    
    toast({
      title: "Reservation cancelled",
      description: "Your reservation has been cancelled successfully.",
    });
  };

  const handleConfirmPickup = (reservationId: string) => {
    // In a real app, this would be an API call
    setReservations(prevReservations => 
      prevReservations.map(res => {
        if (res.id === reservationId) {
          return {
            ...res,
            status: 'completed',
            completedAt: new Date()
          };
        }
        return res;
      })
    );
    
    toast({
      title: "Pickup confirmed",
      description: "Thank you for confirming your pickup.",
    });
  };

  // Format date for display
  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: 'numeric',
    }).format(date);
  };

  // Render status badge
  const renderStatusBadge = (status: Reservation['status']) => {
    switch (status) {
      case 'pending':
        return <Badge className="bg-yellow-500">Processing</Badge>;
      case 'ready':
        return <Badge className="bg-medigreen-500">Ready for Pickup</Badge>;
      case 'completed':
        return <Badge className="bg-medibleu-500">Completed</Badge>;
      case 'cancelled':
        return <Badge className="bg-gray-500">Cancelled</Badge>;
      default:
        return null;
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Your Reservations</h1>
      
      <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
        <div className="border-b">
          <TabsList className="w-full justify-start">
            <TabsTrigger value="all" className="relative">
              All
              <Badge className="ml-2 bg-gray-500">{reservations.length}</Badge>
            </TabsTrigger>
            <TabsTrigger value="pending">
              Processing
              <Badge className="ml-2 bg-yellow-500">
                {reservations.filter(r => r.status === 'pending').length}
              </Badge>
            </TabsTrigger>
            <TabsTrigger value="ready">
              Ready
              <Badge className="ml-2 bg-medigreen-500">
                {reservations.filter(r => r.status === 'ready').length}
              </Badge>
            </TabsTrigger>
            <TabsTrigger value="completed">
              Completed
              <Badge className="ml-2 bg-medibleu-500">
                {reservations.filter(r => r.status === 'completed').length}
              </Badge>
            </TabsTrigger>
            <TabsTrigger value="cancelled">
              Cancelled
              <Badge className="ml-2 bg-gray-500">
                {reservations.filter(r => r.status === 'cancelled').length}
              </Badge>
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value={activeTab} className="pt-6">
          {isLoading ? (
            <div className="text-center py-12">
              <p className="text-gray-500">Loading reservations...</p>
            </div>
          ) : filteredReservations.length === 0 ? (
            <div className="text-center py-12 bg-white rounded-lg shadow-md">
              <div className="inline-flex items-center justify-center w-20 h-20 bg-gray-100 rounded-full mb-4">
                <AlertCircle className="h-10 w-10 text-gray-400" />
              </div>
              <h2 className="text-xl font-semibold text-gray-800 mb-2">
                No {activeTab === 'all' ? '' : activeTab} reservations found
              </h2>
              <p className="text-gray-600 mb-6">
                {activeTab === 'all' 
                  ? "You haven't made any medicine reservations yet." 
                  : `You don't have any ${activeTab} reservations at the moment.`}
              </p>
              <Button 
                className="bg-medibleu-500 hover:bg-medibleu-600"
                onClick={() => window.location.href = '/search'}
              >
                Browse Medicines
              </Button>
            </div>
          ) : (
            <div className="space-y-6">
              {filteredReservations.map(reservation => (
                <div 
                  key={reservation.id} 
                  className="bg-white rounded-lg shadow-md overflow-hidden border border-gray-100"
                >
                  {/* Reservation Header */}
                  <div className="bg-gray-50 p-4 border-b border-gray-100 flex flex-col md:flex-row md:items-center md:justify-between">
                    <div>
                      <div className="flex items-center">
                        <h3 className="text-lg font-semibold text-gray-800">
                          Reservation #{reservation.id.substring(3)}
                        </h3>
                        <div className="ml-4">
                          {renderStatusBadge(reservation.status)}
                        </div>
                      </div>
                      <div className="flex items-center mt-2 text-sm text-gray-600">
                        <Calendar className="h-4 w-4 mr-1" />
                        <span>Reserved on {formatDate(reservation.createdAt)}</span>
                      </div>
                    </div>
                    
                    <div className="mt-3 md:mt-0 text-right">
                      <p className="text-sm text-gray-600">Total Amount</p>
                      <p className="text-lg font-semibold text-medibleu-600">
                        ${reservation.total.toFixed(2)}
                      </p>
                    </div>
                  </div>
                  
                  {/* Pharmacy Info */}
                  <div className="p-4 border-b border-gray-100">
                    <h4 className="font-medium mb-2">Pharmacy Information</h4>
                    <div className="space-y-2">
                      <div className="flex items-start">
                        <div className="flex-shrink-0 mt-1">
                          <MapPin className="h-5 w-5 text-gray-500" />
                        </div>
                        <div className="ml-2">
                          <p className="text-gray-800 font-medium">{reservation.pharmacyName}</p>
                          <p className="text-gray-600 text-sm">{reservation.pharmacyAddress}</p>
                        </div>
                      </div>
                      <div className="flex items-center">
                        <Phone className="h-5 w-5 text-gray-500" />
                        <p className="text-gray-600 text-sm ml-2">{reservation.pharmacyPhone}</p>
                      </div>
                    </div>
                  </div>
                  
                  {/* Reservation Status Details */}
                  {reservation.status === 'ready' && (
                    <div className="p-4 bg-medigreen-50 border-b border-gray-100 flex items-center">
                      <CheckCircle className="h-5 w-5 text-medigreen-500 mr-2" />
                      <div>
                        <p className="text-medigreen-800 font-medium">Your medicines are ready for pickup!</p>
                        <p className="text-medigreen-700 text-sm">
                          Ready since {reservation.readyAt && formatDate(reservation.readyAt)}
                        </p>
                      </div>
                    </div>
                  )}
                  {reservation.status === 'pending' && (
                    <div className="p-4 bg-yellow-50 border-b border-gray-100 flex items-center">
                      <Clock className="h-5 w-5 text-yellow-500 mr-2" />
                      <div>
                        <p className="text-yellow-800 font-medium">Your reservation is being processed</p>
                        <p className="text-yellow-700 text-sm">
                          We'll notify you when your medicines are ready for pickup
                        </p>
                      </div>
                    </div>
                  )}
                  {reservation.status === 'cancelled' && (
                    <div className="p-4 bg-gray-50 border-b border-gray-100 flex items-center">
                      <XCircle className="h-5 w-5 text-gray-500 mr-2" />
                      <div>
                        <p className="text-gray-800 font-medium">Reservation cancelled</p>
                        <p className="text-gray-600 text-sm">
                          Cancelled on {reservation.cancelledAt && formatDate(reservation.cancelledAt)}
                        </p>
                      </div>
                    </div>
                  )}
                  {reservation.status === 'completed' && (
                    <div className="p-4 bg-medibleu-50 border-b border-gray-100 flex items-center">
                      <CheckCircle className="h-5 w-5 text-medibleu-500 mr-2" />
                      <div>
                        <p className="text-medibleu-800 font-medium">Reservation completed</p>
                        <p className="text-medibleu-700 text-sm">
                          Picked up on {reservation.completedAt && formatDate(reservation.completedAt)}
                        </p>
                      </div>
                    </div>
                  )}
                  
                  {/* Medicines List */}
                  <div className="p-4">
                    <h4 className="font-medium mb-3">Reserved Medicines</h4>
                    <div className="divide-y divide-gray-100">
                      {reservation.items.map(item => (
                        <div key={item.id} className="py-3 flex items-center">
                          <div className="flex-grow">
                            <h5 className="text-gray-800">{item.name}</h5>
                            <p className="text-gray-500 text-sm">{item.dosage}</p>
                          </div>
                          <div className="text-right">
                            <p className="text-gray-800 font-medium">${(item.price * item.quantity).toFixed(2)}</p>
                            <p className="text-gray-500 text-sm">{item.quantity} × ${item.price.toFixed(2)}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  {/* Actions */}
                  <div className="bg-gray-50 p-4 border-t border-gray-100 flex flex-col sm:flex-row sm:justify-end space-y-2 sm:space-y-0 sm:space-x-3">
                    {reservation.status === 'ready' && (
                      <>
                        <Button 
                          variant="outline" 
                          className="border-gray-300"
                          onClick={() => handleCancelReservation(reservation.id)}
                        >
                          Cancel Reservation
                        </Button>
                        <Button 
                          className="bg-medigreen-500 hover:bg-medigreen-600"
                          onClick={() => handleConfirmPickup(reservation.id)}
                        >
                          Confirm Pickup
                        </Button>
                      </>
                    )}
                    {reservation.status === 'pending' && (
                      <Button 
                        variant="outline" 
                        className="border-gray-300"
                        onClick={() => handleCancelReservation(reservation.id)}
                      >
                        Cancel Reservation
                      </Button>
                    )}
                    {(reservation.status === 'completed' || reservation.status === 'cancelled') && (
                      <Button 
                        variant="outline" 
                        className="border-medibleu-500 text-medibleu-500"
                        onClick={() => window.location.href = '/search'}
                      >
                        Reserve Again
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Reservations;
