
import React, { createContext, useState, useContext, useEffect } from 'react';

// User Types
export type UserRole = 'user' | 'pharmacist' | 'admin';

export interface User {
  id: string;
  name?: string;
  email: string;
  role: UserRole;
  avatar?: string;
  phoneNumber?: string;
}

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (email: string, password: string, name: string, role: UserRole) => Promise<void>;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  loading: true,
  login: async () => {},
  register: async () => {},
  logout: () => {},
  isAuthenticated: false,
});

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  // Load user from localStorage on startup
  useEffect(() => {
    const storedUser = localStorage.getItem('medireach_user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    setLoading(false);
  }, []);

  // Mock login function - replace with real API call in production
  const login = async (email: string, password: string) => {
    try {
      setLoading(true);
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Mock API response
      const mockUsers = [
        { id: '1', name: 'John Patient', email: 'user@example.com', password: 'password', role: 'user' as UserRole },
        { id: '2', name: 'Dr. Sarah Pharmacist', email: 'pharmacist@example.com', password: 'password', role: 'pharmacist' as UserRole },
        { id: '3', name: 'Admin User', email: 'admin@example.com', password: 'password', role: 'admin' as UserRole },
      ];

      const foundUser = mockUsers.find(u => u.email === email && u.password === password);
      
      if (!foundUser) {
        throw new Error('Invalid email or password');
      }

      // Remove password from user object
      const { password: _, ...userWithoutPassword } = foundUser;
      
      // Store in localStorage and state
      localStorage.setItem('medireach_user', JSON.stringify(userWithoutPassword));
      setUser(userWithoutPassword);
    } catch (error) {
      throw error;
    } finally {
      setLoading(false);
    }
  };

  // Mock register function - replace with real API call in production
  const register = async (email: string, password: string, name: string, role: UserRole) => {
    try {
      setLoading(true);
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 1000));

      // In a real app, would send data to server
      const newUser = {
        id: Date.now().toString(),
        name,
        email,
        role,
      };

      // Store in localStorage and state
      localStorage.setItem('medireach_user', JSON.stringify(newUser));
      setUser(newUser);
    } catch (error) {
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    localStorage.removeItem('medireach_user');
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{
      user,
      loading,
      login,
      register,
      logout,
      isAuthenticated: !!user,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
