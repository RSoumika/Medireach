import React, { createContext, useState, useContext, useEffect } from 'react';

export interface Medicine {
  id: string;
  name: string;
  price: number;
  description?: string;
  dosage?: string;
  manufacturer?: string;
  image: string;
  inStock: boolean;
  location?: {
    lat: number;
    lng: number;
  };
}

export interface CartItem {
  medicine: Medicine;
  quantity: number;
  pharmacyId: string;
  pharmacyName: string;
}

interface CartContextType {
  cart: {
    items: CartItem[];
    total: number;
  };
  addToCart: (medicine: Medicine, quantity: number, pharmacyId: string, pharmacyName: string) => void;
  removeFromCart: (medicineId: string) => void;
  updateQuantity: (medicineId: string, quantity: number) => void;
  clearCart: () => void;
}

const CartContext = createContext<CartContextType>({
  cart: {
    items: [],
    total: 0,
  },
  addToCart: () => {},
  removeFromCart: () => {},
  updateQuantity: () => {},
  clearCart: () => {},
});

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [cart, setCart] = useState<{
    items: CartItem[];
    total: number;
  }>({
    items: [],
    total: 0,
  });

  useEffect(() => {
    const storedCart = localStorage.getItem('medireach_cart');
    if (storedCart) {
      setCart(JSON.parse(storedCart));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('medireach_cart', JSON.stringify(cart));
  }, [cart]);

  const calculateTotal = (items: CartItem[]): number => {
    return items.reduce((total, item) => total + (item.medicine.price * item.quantity), 0);
  };

  const addToCart = (medicine: Medicine, quantity: number, pharmacyId: string, pharmacyName: string) => {
    setCart(prevCart => {
      const existingItemIndex = prevCart.items.findIndex(item => item.medicine.id === medicine.id);
      
      let newItems;
      if (existingItemIndex >= 0) {
        newItems = [...prevCart.items];
        newItems[existingItemIndex] = {
          ...newItems[existingItemIndex],
          quantity: newItems[existingItemIndex].quantity + quantity,
        };
      } else {
        newItems = [...prevCart.items, { medicine, quantity, pharmacyId, pharmacyName }];
      }
      
      return {
        items: newItems,
        total: calculateTotal(newItems),
      };
    });
  };

  const removeFromCart = (medicineId: string) => {
    setCart(prevCart => {
      const newItems = prevCart.items.filter(item => item.medicine.id !== medicineId);
      return {
        items: newItems,
        total: calculateTotal(newItems),
      };
    });
  };

  const updateQuantity = (medicineId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(medicineId);
      return;
    }
    
    setCart(prevCart => {
      const newItems = prevCart.items.map(item => {
        if (item.medicine.id === medicineId) {
          return {
            ...item,
            quantity,
          };
        }
        return item;
      });
      
      return {
        items: newItems,
        total: calculateTotal(newItems),
      };
    });
  };

  const clearCart = () => {
    setCart({
      items: [],
      total: 0,
    });
  };

  return (
    <CartContext.Provider value={{
      cart,
      addToCart,
      removeFromCart,
      updateQuantity,
      clearCart,
    }}>
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => useContext(CartContext);
