
import React from 'react';
import Header from './Header';
import Footer from './Footer';
import AIChatbot from '@/components/chatbot/AIChatbot';
import { useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const location = useLocation();
  const { user } = useAuth();

  // Check if the current page is login or register to hide header and footer
  const isAuthPage = location.pathname === '/login' || location.pathname === '/register';
  
  // Check if current page is a dashboard page (only show chatbot on user pages)
  const isDashboardPage = 
    location.pathname === '/admin-dashboard' || 
    location.pathname === '/pharmacy-dashboard';

  return (
    <div className="flex flex-col min-h-screen">
      {!isAuthPage && <Header />}
      <main className="flex-1">
        {children}
      </main>
      {!isAuthPage && <Footer />}
      {/* Only show chatbot on user pages, not on auth pages or dashboard pages */}
      {!isAuthPage && !isDashboardPage && <AIChatbot />}
    </div>
  );
};

export default Layout;
