
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Bell, Menu, ShoppingCart, X } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { Badge } from '@/components/ui/badge';
import { useCart } from '@/contexts/CartContext';
import MediReachLogo from '@/components/common/MediReachLogo';

const Header = () => {
  const { user, logout } = useAuth();
  const { cart } = useCart();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  const cartItemsCount = cart.items.length;

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center">
          <MediReachLogo className="h-8 w-auto" />
          <span className="ml-2 text-xl font-bold text-medibleu-600">MediReach</span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-6">
          <Link to="/search" className="text-gray-600 hover:text-medibleu-600 transition-colors">
            Find Medicines
          </Link>
          <Link to="/pharmacies" className="text-gray-600 hover:text-medibleu-600 transition-colors">
            Pharmacies
          </Link>
          <Link to="/reservations" className="text-gray-600 hover:text-medibleu-600 transition-colors">
            My Reservations
          </Link>
          <Link to="/about" className="text-gray-600 hover:text-medibleu-600 transition-colors">
            About
          </Link>
        </nav>

        {/* Right Side Actions */}
        <div className="flex items-center space-x-4">
          {/* Shopping Cart */}
          <Link to="/cart" className="relative text-gray-600 hover:text-medibleu-600">
            <ShoppingCart className="h-5 w-5" />
            {cartItemsCount > 0 && (
              <Badge className="absolute -top-2 -right-2 bg-medigreen-500 text-white text-xs">
                {cartItemsCount}
              </Badge>
            )}
          </Link>

          {/* Notifications */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="relative p-2">
                <Bell className="h-5 w-5" />
                <Badge className="absolute -top-1 -right-1 bg-medigreen-500 text-white text-xs">2</Badge>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-80">
              <DropdownMenuLabel>Notifications</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <div className="max-h-[300px] overflow-y-auto">
                <DropdownMenuItem className="py-3 cursor-pointer">
                  <div>
                    <p className="font-medium">Your reservation is ready</p>
                    <p className="text-sm text-gray-500">Your medicines at PharmaCare are ready for pickup</p>
                    <p className="text-xs text-gray-400 mt-1">2 minutes ago</p>
                  </div>
                </DropdownMenuItem>
                <DropdownMenuItem className="py-3 cursor-pointer">
                  <div>
                    <p className="font-medium">MedPlus updated your request</p>
                    <p className="text-sm text-gray-500">Paracetamol is now available at your requested location</p>
                    <p className="text-xs text-gray-400 mt-1">1 hour ago</p>
                  </div>
                </DropdownMenuItem>
              </div>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="justify-center font-medium text-medibleu-600">
                View all notifications
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Profile/Login */}
          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative p-0 overflow-hidden rounded-full h-8 w-8">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={user.avatar || ''} />
                    <AvatarFallback className="bg-medibleu-100 text-medibleu-600">
                      {user.name?.charAt(0) || 'U'}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>{user.name || 'User'}</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  <Link to="/profile" className="w-full">My Profile</Link>
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Link to="/reservations" className="w-full">My Reservations</Link>
                </DropdownMenuItem>
                {user.role === 'pharmacist' && (
                  <DropdownMenuItem>
                    <Link to="/pharmacy-dashboard" className="w-full">Pharmacy Dashboard</Link>
                  </DropdownMenuItem>
                )}
                {user.role === 'admin' && (
                  <DropdownMenuItem>
                    <Link to="/admin-dashboard" className="w-full">Admin Dashboard</Link>
                  </DropdownMenuItem>
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={logout} className="text-red-500 cursor-pointer">
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <div className="flex items-center space-x-2">
              <Link to="/login">
                <Button variant="ghost" size="sm">Login</Button>
              </Link>
              <Link to="/register">
                <Button className="bg-medibleu-500 hover:bg-medibleu-600" size="sm">Register</Button>
              </Link>
            </div>
          )}

          {/* Mobile Menu Toggle */}
          <Button 
            variant="ghost" 
            size="icon" 
            className="block md:hidden" 
            onClick={toggleMobileMenu}
          >
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="block md:hidden bg-white border-t border-gray-100 px-4 pb-4">
          <nav className="flex flex-col space-y-3 py-3">
            <Link 
              to="/search" 
              className="text-gray-600 hover:text-medibleu-600 transition-colors py-2"
              onClick={toggleMobileMenu}
            >
              Find Medicines
            </Link>
            <Link 
              to="/pharmacies" 
              className="text-gray-600 hover:text-medibleu-600 transition-colors py-2"
              onClick={toggleMobileMenu}
            >
              Pharmacies
            </Link>
            <Link 
              to="/reservations" 
              className="text-gray-600 hover:text-medibleu-600 transition-colors py-2"
              onClick={toggleMobileMenu}
            >
              My Reservations
            </Link>
            <Link 
              to="/about" 
              className="text-gray-600 hover:text-medibleu-600 transition-colors py-2"
              onClick={toggleMobileMenu}
            >
              About
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;
