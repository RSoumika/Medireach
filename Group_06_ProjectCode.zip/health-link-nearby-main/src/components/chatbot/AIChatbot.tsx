
import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface Message {
  id: string;
  content: string;
  sender: 'user' | 'bot';
  timestamp: Date;
}

const AIChatbot: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      content: 'Hello! I\'m your MediReach assistant. I can help you find alternative medicines if what you\'re looking for is unavailable. How can I help you today?',
      sender: 'bot',
      timestamp: new Date(),
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom whenever messages change
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  const toggleChatbot = () => {
    setIsOpen(!isOpen);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputValue(e.target.value);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputValue.trim() === '') return;

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputValue,
      sender: 'user',
      timestamp: new Date(),
    };
    
    setMessages(prevMessages => [...prevMessages, userMessage]);
    setInputValue('');
    setIsTyping(true);

    // Enhanced database of alternative medicines with Indian context
    const alternativeMedicines: Record<string, {alternatives: string[], descriptions: string[]}> = {
      'paracetamol': {
        alternatives: ['Crocin', 'Dolo 650', 'Calpol'],
        descriptions: [
          'Common brand for fever and pain relief',
          'Popular for fever and headache relief',
          'Effective for children and adults for fever'
        ]
      },
      'ibuprofen': {
        alternatives: ['Brufen', 'Combiflam', 'Ibugesic'],
        descriptions: [
          'Anti-inflammatory pain reliever',
          'Combination of paracetamol and ibuprofen',
          'Rapid-relief formulation for pain'
        ]
      },
      'aspirin': {
        alternatives: ['Disprin', 'Ecosprin', 'Loprin'],
        descriptions: [
          'Blood thinner and pain reliever',
          'Low-dose aspirin for heart patients',
          'Preventive medication for cardiac patients'
        ]
      },
      'amoxicillin': {
        alternatives: ['Novamox', 'Wymox', 'Mox'],
        descriptions: [
          'Common antibiotic for bacterial infections',
          'Effective for respiratory infections',
          'Broad-spectrum antibiotic'
        ]
      },
      'azithromycin': {
        alternatives: ['Azee', 'Zithromax', 'Aziwok'],
        descriptions: [
          'Macrolide antibiotic for infections',
          'Often prescribed for respiratory infections',
          '3-5 day course antibiotic'
        ]
      },
      'lisinopril': {
        alternatives: ['Lisoril', 'Listril', 'Zestril'],
        descriptions: [
          'ACE inhibitor for blood pressure',
          'Helps manage hypertension',
          'Protects kidney function in diabetics'
        ]
      },
      'atorvastatin': {
        alternatives: ['Atorva', 'Lipitor', 'Atocor'],
        descriptions: [
          'Statin for cholesterol management',
          'Reduces LDL cholesterol levels',
          'Prevents cardiovascular diseases'
        ]
      },
      'metformin': {
        alternatives: ['Glycomet', 'Glucophage', 'Obimet'],
        descriptions: [
          'First-line medication for Type 2 diabetes',
          'Helps control blood sugar levels',
          'Improves insulin sensitivity'
        ]
      },
      'pantoprazole': {
        alternatives: ['Pan', 'Pantocid', 'Pantodac'],
        descriptions: [
          'Proton pump inhibitor for acidity',
          'Treats gastric ulcers and GERD',
          'Reduces stomach acid production'
        ]
      },
      'cetirizine': {
        alternatives: ['Alerid', 'Cetcip', 'Zyrtec'],
        descriptions: [
          'Antihistamine for allergies',
          'Treats runny nose and sneezing',
          'Non-drowsy allergy medication'
        ]
      },
    };

    // Check if the user message contains any medicine names
    const userMessageLower = userMessage.content.toLowerCase();
    let botResponse = '';
    
    // Find if any medicine name is mentioned
    const foundMedicine = Object.keys(alternativeMedicines).find(medicine => 
      userMessageLower.includes(medicine)
    );
    
    if (foundMedicine) {
      const alternatives = alternativeMedicines[foundMedicine].alternatives;
      const descriptions = alternativeMedicines[foundMedicine].descriptions;
      
      // Create a more detailed response with information about each alternative
      let alternativesText = '';
      alternatives.forEach((alt, index) => {
        alternativesText += `\n- ${alt}: ${descriptions[index]}`;
      });
      
      botResponse = `If ${foundMedicine} is unavailable, here are some alternatives available in Guntur pharmacies:${alternativesText}\n\nWould you like me to help you find which nearby pharmacy has these medicines in stock?`;
    } else if (userMessageLower.includes('medicine') || userMessageLower.includes('drug') || userMessageLower.includes('medication') || userMessageLower.includes('tablet')) {
      botResponse = 'I can help you find alternative medicines. Could you please specify which medicine you\'re looking for? For example, paracetamol, ibuprofen, cetirizine, etc.';
    } else {
      botResponse = 'I\'m here to help you find alternative medicines. Please let me know which medicine you\'re looking for, and I\'ll suggest some alternatives that are available in Guntur pharmacies.';
    }

    const botMessage: Message = {
      id: Date.now().toString(),
      content: botResponse,
      sender: 'bot',
      timestamp: new Date(),
    };
    
    // Simulate AI response after a delay
    setTimeout(() => {
      setMessages(prevMessages => [...prevMessages, botMessage]);
      setIsTyping(false);
    }, 1500);
  };

  return (
    <>
      {/* Floating button */}
      <button
        onClick={toggleChatbot}
        className={cn(
          "fixed bottom-6 right-6 z-50 rounded-full p-4 shadow-lg transition-all duration-300",
          isOpen ? "bg-red-500 hover:bg-red-600" : "bg-medibleu-600 hover:bg-medibleu-700 animate-float"
        )}
      >
        {isOpen ? (
          <X className="h-6 w-6 text-white" />
        ) : (
          <MessageCircle className="h-6 w-6 text-white" />
        )}
      </button>

      {/* Chatbot panel */}
      <div
        className={cn(
          "fixed bottom-24 right-6 z-50 w-80 sm:w-96 rounded-lg shadow-xl bg-white transition-all duration-300 transform",
          isOpen ? "scale-100 opacity-100" : "scale-90 opacity-0 pointer-events-none"
        )}
      >
        {/* Header */}
        <div className="bg-medibleu-600 rounded-t-lg p-4 flex justify-between items-center">
          <div className="flex items-center text-white">
            <MessageCircle className="h-5 w-5 mr-2" />
            <h3 className="font-semibold">MediReach Assistant</h3>
          </div>
          <Button variant="ghost" size="sm" onClick={toggleChatbot} className="text-white hover:text-white/80 p-1">
            <ChevronDown className="h-5 w-5" />
          </Button>
        </div>

        {/* Chat messages */}
        <div className="h-80 overflow-y-auto p-4 bg-gray-50">
          {messages.map(message => (
            <div
              key={message.id}
              className={cn(
                "mb-4 max-w-[80%] rounded-lg p-3",
                message.sender === 'user' 
                  ? "bg-medibleu-500 text-white ml-auto" 
                  : "bg-white shadow text-gray-800"
              )}
            >
              <p className="whitespace-pre-line">{message.content}</p>
              <div
                className={cn(
                  "text-xs mt-1",
                  message.sender === 'user' ? "text-blue-100" : "text-gray-500"
                )}
              >
                {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </div>
            </div>
          ))}
          {isTyping && (
            <div className="bg-white shadow rounded-lg p-3 max-w-[80%] mb-4">
              <div className="flex space-x-2">
                <div className="w-2 h-2 rounded-full bg-gray-300 animate-bounce" />
                <div className="w-2 h-2 rounded-full bg-gray-300 animate-bounce" style={{ animationDelay: '0.2s' }} />
                <div className="w-2 h-2 rounded-full bg-gray-300 animate-bounce" style={{ animationDelay: '0.4s' }} />
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input form */}
        <form onSubmit={handleSubmit} className="border-t p-2 flex items-center">
          <input
            type="text"
            value={inputValue}
            onChange={handleInputChange}
            placeholder="Ask about alternative medicines..."
            className="flex-1 py-2 px-3 rounded-md border focus:outline-none focus:ring-2 focus:ring-medibleu-500"
          />
          <Button 
            type="submit" 
            className="ml-2 bg-medibleu-500 hover:bg-medibleu-600 p-2"
            disabled={inputValue.trim() === ''}
          >
            <Send className="h-5 w-5" />
          </Button>
        </form>
      </div>
    </>
  );
};

export default AIChatbot;
