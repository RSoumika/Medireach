
import React from 'react';

interface MediReachLogoProps {
  className?: string;
}

const MediReachLogo: React.FC<MediReachLogoProps> = ({ className = 'h-8 w-auto' }) => {
  return (
    <svg
      className={className}
      viewBox="0 0 50 50"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <circle cx="25" cy="25" r="20" fill="#1a73e8" />
      <path
        d="M25 15V35M20 20H30M20 30H30"
        stroke="white"
        strokeWidth="4"
        strokeLinecap="round"
      />
      <circle cx="25" cy="25" r="23" stroke="#1a73e8" strokeWidth="2" />
    </svg>
  );
};

export default MediReachLogo;
